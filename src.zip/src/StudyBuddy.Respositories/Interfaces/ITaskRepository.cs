﻿using StudyBuddy.Core.Entities;

namespace StudyBuddy.Repositories.Interfaces
{
    public interface ITaskRepository : IBaseRepository<StudyTask> { }
}
