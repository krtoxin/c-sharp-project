﻿namespace StudyBuddy.Core.Enums
{
    public enum AttachmentType
    {
        None,
        Task,
        Image,
        Pdf
    }
}
