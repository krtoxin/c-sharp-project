﻿namespace StudyBuddy.Core.Enums
{
    public enum ChatRole
    {
        Member,
        Admin
    }
}
