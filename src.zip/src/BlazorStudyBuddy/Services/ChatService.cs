﻿namespace StudyBuddyWebBlazor.Services
{
    public class ChatService
    {
    }
}
