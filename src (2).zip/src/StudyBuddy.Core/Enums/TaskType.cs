﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyBuddy.Core.Enums
{
    public enum TaskType
    {
        OpenEnded = 0,
        MultipleChoice = 1,
        TrueFalse = 2
    }

}
