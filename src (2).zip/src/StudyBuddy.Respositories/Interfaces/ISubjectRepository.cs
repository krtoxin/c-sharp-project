﻿using StudyBuddy.Core.Entities;

namespace StudyBuddy.Repositories.Interfaces
{
    public interface ISubjectRepository : IBaseRepository<Subject>
    {
    }
}
